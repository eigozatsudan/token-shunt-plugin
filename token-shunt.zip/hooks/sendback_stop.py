"""Stop hook: send a parent back when it dropped a worker's lines.

It ships with the plugin and is registered in `plugin/hooks/hooks.json`
on both Stop (the parent) and SubagentStop (the reader worker), through
the `check-final-answer` executable. `TOKEN_SHUNT_SENDBACK=off` turns it
off. The conditions that had to hold before registering are recorded in
`reviews/sendback-registration-decision-2026-09-15.md`.

It blocks only where the offline checks can actually judge the parent
(spec section 1): worker output obtained, worker items usable, final
answer identified, and a line-retention violation. Anything undetermined,
and any failure on the worker's side, returns success -- sending those
back would break answers that are correct.

Every invocation appends one JSON record to the trial log, including the
counts that section 4.1 uses as evidence of resumption. The record is what
the trial reads afterwards; the hook itself concludes nothing about why a
parent did or did not resume.
"""
import hashlib
import json
import os
import re
import sys
import tempfile

import sendback_retention as rc
import sendback_session as se

LOG_ENV = 'SENDBACK_TRIAL_LOG'
SIZE_ENV = 'TOKEN_SHUNT_SESSION_MAX_BYTES'
SWITCH_ENV = 'TOKEN_SHUNT_SENDBACK'
# The only worker under the reader contract. Other agents -- the writer,
# anything the user delegates to -- are not judged by it.
WORKER_AGENT = 'token-shunt:bulk-reader'
OFF = ('off', '0', 'false', 'no')

# The hook runs at every turn end and a session file only grows. The cap
# bounds the worst case rather than excluding ordinary work: the largest
# session on hand when this was written was 17 MB, which parses once in
# about 0.15 s, so 64 MB is roughly four times the observed ceiling and
# still well under a second. Over it, the parent is left alone.
DEFAULT_MAX_BYTES = 64 * 1024 * 1024

# The oldest CLI whose Stop payload was verified to carry
# `last_assistant_message` (see the registration decision, section 3.3).
# Not a claim about when the field appeared: it is the oldest build that
# could be checked here, and every build from it to 2.1.272 declares the
# field identically.
VERSION_FLOOR = (2, 1, 269)

DISABLED = 'disabled'
TOO_LARGE = 'too_large'
BLOCKED = 'blocked'
NO_BLOCK = 'no_block'
SUPPRESSED = 'reblock_suppressed'
EARLY = 'early_stop'

# One relapse block per session, ever. The budget is what keeps this from
# becoming the loop `stop_hook_active` prevents: the parent can be told
# once that it closed on a shorter answer, and never a second time.
RELAPSE_BUDGET = 1

# Statuses the CLI reports for work that has not finished. A stop while one
# of these is outstanding is a pause, not the end of the answer.
PENDING = ('running', 'pending', 'in_progress', 'queued', 'backgrounded')


def parent_progress(rows):
    """What counts as the parent having acted, per spec section 4.1.

    Assistant replies and the parent's own tool calls are the evidence of
    a resumption. Transcript line counts are not: a hook record, a task
    notification or a meta update grows the file without the parent having
    said anything, so lines are carried only as auxiliary information.
    """
    replies = calls = 0
    for entry in rows:
        if entry.get('type') != 'assistant' or entry.get('isSidechain'):
            continue
        replies += 1
        for block in (entry.get('message') or {}).get('content') or []:
            if isinstance(block, dict) and block.get('type') == 'tool_use':
                calls += 1
    return {'assistant_replies': replies, 'tool_calls': calls,
            'transcript_lines': len(rows)}


def resumption(baseline, rows):
    """Did the parent respond after the block?

    'resumed' requires a new parent reply or a new parent tool call.
    Otherwise the cause is left open: a transcript does not distinguish a
    discarded block from any other reason the parent stayed silent, so the
    trial records `cause_unknown` rather than naming the discard path.
    """
    now = parent_progress(rows)
    grew = (now['assistant_replies'] > baseline.get('assistant_replies', 0)
            or now['tool_calls'] > baseline.get('tool_calls', 0))
    return {'status': 'resumed' if grew else 'not_resumed',
            'cause': '' if grew else 'cause_unknown',
            'before': baseline, 'after': now,
            # Auxiliary only. Lines can grow without the parent acting.
            'line_growth': now['transcript_lines']
                           - baseline.get('transcript_lines', 0)}


def in_flight_workers(event):
    """Subagent tasks the CLI reports as still outstanding at this stop.

    The Stop hook also fires while a worker is still running -- the parent's
    turn ends and resumes when the report arrives. The lines that worker has
    not delivered yet are not lines the parent dropped, so such a stop is
    recorded apart and never judged.
    """
    out = []
    for task in event.get('background_tasks') or []:
        if not isinstance(task, dict):
            continue
        if task.get('type') != 'subagent':
            continue
        if str(task.get('status', '')).lower() in PENDING:
            out.append({'id': task.get('id'),
                        'agent_type': task.get('agent_type'),
                        'status': task.get('status')})
    return out


def final_from_event(event, rows):
    """The answer this stop is about, preferring what the CLI handed us.

    The Stop input carries `last_assistant_message`, the text of the message
    the turn is ending on, which is why the trial's transcript reading failed:
    at hook time that message is not in the session file yet.

    It is used only when it is the CURRENT turn's text. If the same text
    already appears before the last interruption, it is narration from an
    earlier turn -- the CLI hands over the last assistant message, which need
    not be a turn-ending one when the turn ended on a tool result. Such a
    stop is left unidentified rather than judged against stale text.
    """
    said = event.get('last_assistant_message')
    if isinstance(said, str) and said.strip():
        cut = -1
        for i, entry in enumerate(rows):
            if se._is_interruption(entry):
                cut = i
        earlier = set()
        for entry in rows[:cut + 1]:
            if entry.get('type') != 'assistant' or entry.get('isSidechain'):
                continue
            for block in (entry.get('message') or {}).get('content') or []:
                if isinstance(block, dict) and block.get('type') == 'text' \
                        and block.get('text'):
                    earlier.add(rc.normalize(block['text']))
        if rc.normalize(said) in earlier:
            return None, 'last_assistant_message repeats earlier narration'
        return said, 'last_assistant_message'
    got = se.final_answer_from_rows(rows)
    if got['status'] == 'ok':
        return got['text'], 'transcript'
    return None, 'final answer not identified'


def enabled():
    """Whether this turn end is judged at all.

    On by default: that is the product's behaviour. The comparison eval
    turns it off so its baseline keeps measuring the skills rather than
    the send-back (decision section 3.4). The runner sets the variable
    itself after clearing every TOKEN_SHUNT_* name, so a caller's
    environment cannot decide this for it.
    """
    return os.environ.get(SWITCH_ENV, '').strip().lower() not in OFF


def parse_version(text):
    """'2.1.272' -> (2, 1, 272); anything else -> None."""
    if not isinstance(text, str):
        return None
    parts = text.split('.')[:3]
    if len(parts) < 3 or not all(p.isdigit() for p in parts):
        return None
    return tuple(int(p) for p in parts)


def cli_version(rows):
    """The CLI that wrote the session, from its own rows.

    The Stop payload carries no version, but every assistant and user row
    records the build that wrote it, and the newest of those is the CLI
    running now. It costs nothing: the rows are already parsed.
    """
    for entry in reversed(rows):
        got = entry.get('version')
        if isinstance(got, str) and got:
            return got
    return None


def max_bytes():
    raw = os.environ.get(SIZE_ENV)
    try:
        val = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_MAX_BYTES
    return val if val > 0 else DEFAULT_MAX_BYTES


def worker_block_reason(check):
    """What the worker must fix, in its own terms.

    Both violations are the worker holding the facts and not stating them
    in the contracted form, which is something it can fix by restating.
    A citation naming a file that no longer exists is undetermined, never
    a violation, and never reaches here.
    """
    if not check['items']:
        return ('token-shunt: your report carried no confirmed item. State '
                'each fact on its own line as '
                '`confirmed: <absolute path> — <the fact>`, or as '
                '`unconfirmed: <what you could not verify>` where you could '
                'not read it, then finish.')
    head = ('token-shunt: every confirmed item must cite an absolute path. '
            'Restate these lines with the full path of the file each fact '
            'came from, one per line:')
    return '\n'.join([head] + list(check['unusable']))


# A body the CLI wrote in place of a worker turn: the request failed, or
# the account ran out of session. Nothing answered, so nothing can restate
# -- a send-back here spends a turn demanding work of a worker that never
# got to work. Anchored at the start and length-bounded on purpose: a real
# report that merely mentions an API error is still judged.
_INFRA = re.compile(r"^(api error\b"
                    r"|you(?:'| ha)ve hit your (?:session|usage) limit"
                    r"|claude(?: code)? is (?:unavailable|overloaded))", re.I)
_INFRA_MAX = 400


def infrastructure_error(said):
    """Is this the harness reporting a failure rather than a worker report?"""
    body = (said or '').strip()
    return len(body) <= _INFRA_MAX and bool(_INFRA.match(body))


def decide_worker(event):
    """The reader worker's own report, judged before it reaches the parent.

    The parent hook cannot repair what never arrived: a worker that
    reports no confirmed item, or items with no usable path, leaves the
    parent nothing to retain, and the saved corpus shows that is the
    single largest failure left (79 launches). This is the same decision
    shape as the parent's -- block only a violation the worker can fix,
    never something undetermined -- applied one level down.
    """
    rec = {'event': event.get('hook_event_name'),
           'session_id': event.get('session_id'),
           'agent_id': event.get('agent_id'),
           'agent_type': event.get('agent_type'),
           'stop_hook_active': bool(event.get('stop_hook_active'))}
    if rec['stop_hook_active']:
        rec.update(outcome=SUPPRESSED, reason='stop_hook_active')
        return rec, {}
    if event.get('agent_type') != WORKER_AGENT:
        rec.update(outcome=NO_BLOCK, reason='not a bulk-reader worker')
        return rec, {}
    said = event.get('last_assistant_message')
    if not (isinstance(said, str) and said.strip()):
        # Same rule as the parent: the worker's transcript does not yet
        # hold the message this stop is about, so there is nothing to judge.
        rec.update(outcome=NO_BLOCK,
                   reason='worker report not in the SubagentStop input')
        return rec, {}
    if infrastructure_error(said):
        rec.update(outcome=NO_BLOCK,
                   reason='worker turn failed before it reported')
        return rec, {}
    check = rc.check_child_items([said])
    lengths = rc.check_declared_lengths(said)
    fences = rc.check_code_fence(said)
    demoted = rc.unconfirmed_lines(said)
    rec['checks'] = {'child_items': check['status'],
                     'declared_lengths': lengths['status'],
                     'code_fence': fences['status']}
    rec['items'] = len(check['items'])
    rec['unconfirmed'] = len(demoted)
    claims = [l for l in check['items'] if not rc.vacuous_item(l)]
    rec['claims'] = len(claims)
    if demoted and not check['usable'] and not claims:
        # The worker said, in the contracted form, that it could not verify
        # what it was asked for -- an unreadable file, a line past the token
        # limit. Demanding a `confirmed:` line here would be demanding it
        # invent one. This covers the reports that pair `unconfirmed:` with
        # a placeholder head (`confirmed: none`, `confirmed: (none)`): the
        # placeholder is not a citation, and what the report actually says
        # is that nothing could be confirmed.
        #
        # It does not cover a report that states real facts without usable
        # paths and adds an `unconfirmed:` line about something else. That
        # worker has the facts and wrote them outside the contract, which
        # is exactly what a send-back repairs (observed live 2026-09-15:
        # three elided-path items plus one honest `unconfirmed:` line).
        return no_body_or(rec, fences,
                          'worker reported only unconfirmed items')
    if check['status'] != rc.VIOLATION:
        if lengths['status'] == rc.VIOLATION:
            # The worker stated the length and then copied the value short.
            # Nothing outside the report is consulted, so this cannot fire
            # on a report written in the older form.
            rec.update(outcome=BLOCKED, reason=lengths['reason'])
            return rec, {'decision': 'block',
                         'reason': length_block_reason(lengths)}
        return no_body_or(rec, fences,
                          'worker items %s' % check['status'])
    rec.update(outcome=BLOCKED, reason=check['reason'],
               unusable=len(check['unusable']))
    return rec, {'decision': 'block', 'reason': worker_block_reason(check)}


def fence_block_reason(fences):
    head = ('token-shunt: your report put source text in a code fence. The '
            'file\'s own text never goes in the report — not a body, not a '
            'single line, not one value. Restate the fact in prose on a '
            '`confirmed:` line and remove the fence:')
    return '\n'.join([head] + list(fences))


def no_body_or(rec, fences, reason):
    """Block a report that carried source text, or record the given no-block.

    The fence is judged last, so a report that is also missing paths or
    contradicting its own declared length is sent back for that instead:
    one send-back asks for one repair, and those two make the facts
    unusable while a fence only adds what should not be there.
    """
    if fences['status'] != rc.VIOLATION:
        rec.update(outcome=NO_BLOCK, reason=reason)
        return rec, {}
    rec.update(outcome=BLOCKED, reason=fences['reason'])
    return rec, {'decision': 'block', 'reason': fence_block_reason(fences['fences'])}


def length_block_reason(lengths):
    head = ('token-shunt: a value is shorter than the length your own '
            'report gives it. Re-read that range and copy the value again '
            'in one piece, then restate the line with a character count '
            'that matches what you wrote:')
    return '\n'.join([head] + [line for line, _ in lengths['mismatched']])


def block_reason(lost):
    # The text names token-shunt: it is what the parent (and anyone reading
    # the transcript) sees, and the eval's isolation check attributes a
    # hook response by its payload, not by the matcher name.
    head = ('token-shunt: your answer dropped lines the reader worker '
            'confirmed. Restate '
            'every line below verbatim, each on its own line, before you '
            'finish:')
    return '\n'.join([head] + list(lost))


def relapse_state_path(session_id):
    """The private file holding this session's relapse budget, or None."""
    if not isinstance(session_id, str) or not session_id:
        return None
    # TMPDIR is read per call, not through tempfile's cached value: the
    # budget must follow the environment the hook actually runs in.
    root = os.path.join(os.environ.get('TMPDIR') or tempfile.gettempdir(),
                        'token-shunt-sendback-%d' % os.getuid())
    try:
        os.makedirs(root, mode=0o700, exist_ok=True)
        info = os.stat(root)
        if os.path.islink(root) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            return None
    except OSError:
        return None
    return os.path.join(root, hashlib.sha256(session_id.encode()).hexdigest() + '.json')


def take_relapse_budget(session_id):
    """Spend one relapse block for this session, or refuse.

    No usable state means no budget: an unbounded relapse block is the loop
    this hook must not start, so a session that cannot be tracked is left
    suppressed.
    """
    path = relapse_state_path(session_id)
    if not path:
        return False
    try:
        with open(path, 'a+', encoding='utf-8') as fh:
            fh.seek(0)
            raw = fh.read()
            try:
                state = json.loads(raw) if raw else {}
            except ValueError:
                state = {}
            spent = state.get('relapse_blocks')
            spent = spent if isinstance(spent, int) and spent >= 0 else 0
            if spent >= RELAPSE_BUDGET:
                return False
            state['relapse_blocks'] = spent + 1
            fh.seek(0)
            fh.truncate()
            fh.write(json.dumps(state))
        return True
    except OSError:
        return False


def relapse_reason(lost):
    head = ('token-shunt: you restated these lines and then ended the turn '
            'on a shorter answer that drops them again. The last message is '
            'the answer, so put the lines in it, each on its own line, '
            'verbatim:')
    return '\n'.join([head] + list(lost))


def decide_relapse(event, rec):
    """The single question a suppressed Stop still asks.

    Not a re-judging of the answer: the only thing that can block here is a
    turn that already carried the lines and then closed without them
    (reviews/sendback-rescue-2026-09-16.md section 3). Everything else --
    a failed repair, an answer that kept the lines, anything undetermined --
    stays suppressed, which is what it was before this check existed.
    """
    rec.update(outcome=SUPPRESSED, reason='stop_hook_active')
    path = event.get('transcript_path')
    if not path or not os.path.isfile(path):
        return rec, {}
    cap = max_bytes()
    try:
        rows = se.read_jsonl(path, cap)
        got = se.check_inputs(path, rows=rows, max_bytes=cap)
    except se.TooLarge as exc:
        rec.update(reason='stop_hook_active; session too large', size=exc.size)
        return rec, {}
    final, source = final_from_event(event, rows)
    if got['child_texts'] is None or final is None or source != 'last_assistant_message':
        # Without the message that ends the turn there is no relapse to see:
        # the session rows hold the earlier text only.
        return rec, {}
    relapse = rc.check_relapse(got['child_texts'], got['final'], final)
    rec['relapse_status'] = relapse['status']
    if relapse['status'] != rc.VIOLATION:
        rec.update(reason='stop_hook_active; relapse %s' % relapse['status'])
        return rec, {}
    if not take_relapse_budget(event.get('session_id')):
        rec.update(reason='stop_hook_active; relapse block already spent')
        return rec, {}
    rec['checks'] = {k: v['status'] for k, v in
                     rc.run_all(got['child_texts'], final).items()}
    rec.update(outcome=BLOCKED, reason=relapse['reason'], relapse=True,
               lost_lines=len(relapse['lost']),
               baseline=parent_progress(rows))
    return rec, {'decision': 'block', 'reason': relapse_reason(relapse['lost'])}


def decide(event):
    """The hook's whole decision, as a record. No I/O."""
    rec = {'event': event.get('hook_event_name'),
           'session_id': event.get('session_id'),
           'transcript_path': event.get('transcript_path'),
           'stop_hook_active': bool(event.get('stop_hook_active'))}
    if not enabled():
        # Nothing is read, so a disabled hook costs one process start.
        rec.update(outcome=DISABLED, reason='%s is off' % SWITCH_ENV)
        return rec, {}
    if event.get('hook_event_name') == 'SubagentStop' or event.get('agent_id'):
        # A worker concluding, not the parent's answer. The parent's
        # retention contract says nothing about it; the reader contract
        # does, and that is decide_worker's question.
        return decide_worker(event)
    if event.get('hook_event_name') != 'Stop':
        rec.update(outcome=NO_BLOCK, reason='not a Stop event')
        return rec, {}
    if rec['stop_hook_active']:
        # The documented contract: return success while this is true. That
        # is the hook declining to re-block -- NOT an observation that the
        # CLI hit its cap (spec section 4.4). The one exception is a turn
        # that restated the lines and then closed without them, which
        # decide_relapse judges and blocks at most once per session.
        return decide_relapse(event, rec)
    waiting = in_flight_workers(event)
    if waiting:
        # Not a no_block verdict on the parent: there is no finished answer
        # to judge yet, and the missing lines are still in transit.
        rec.update(outcome=EARLY, reason='worker still running',
                   in_flight=waiting)
        return rec, {}
    path = event.get('transcript_path')
    if not path or not os.path.isfile(path):
        rec.update(outcome=NO_BLOCK, reason='no transcript to read')
        return rec, {}
    cap = max_bytes()
    try:
        # One parse of the session, reused for the final answer, the worker
        # correlation and the resumption baseline.
        rows = se.read_jsonl(path, cap)
        got = se.check_inputs(path, rows=rows, max_bytes=cap)
    except se.TooLarge as exc:
        rec.update(outcome=TOO_LARGE, reason=str(exc), size=exc.size, cap=cap)
        return rec, {}
    final, source = final_from_event(event, rows)
    checks = rc.run_all(got['child_texts'], final)
    rec['checks'] = {k: v['status'] for k, v in checks.items()}
    rec['final_identified'] = final is not None
    rec['final_source'] = source
    version = cli_version(rows)
    parsed = parse_version(version)
    rec['cli_version'] = version
    # Recorded on every invocation, so a build that stops supplying the
    # field is visible in the log instead of quietly blocking nothing.
    rec['below_version_floor'] = bool(parsed and parsed < VERSION_FLOOR)
    rec['child_blocked'] = got.get('child_blocked', 0)
    if got['child_texts'] is None:
        rec.update(outcome=NO_BLOCK, reason='worker output unobtainable')
        return rec, {}
    if final is None:
        rec.update(outcome=NO_BLOCK, reason=source)
        return rec, {}
    if checks['child_items']['status'] != rc.OK:
        rec.update(outcome=NO_BLOCK,
                   reason='worker side: %s' % checks['child_items']['status'])
        return rec, {}
    lr = checks['line_retention']
    if lr['status'] != rc.VIOLATION:
        rec.update(outcome=NO_BLOCK, reason='retention %s' % lr['status'])
        return rec, {}
    if source != 'last_assistant_message':
        # The only answer in hand came from the session file, and at hook
        # time the message ending this turn is not in it yet -- what was
        # read is an earlier turn's text. Blocking on it would invent a
        # violation, so a transcript-sourced answer is recorded and left
        # alone. This is also what an older CLI, one that does not supply
        # the field, falls back to (section 3.3).
        rec.update(outcome=NO_BLOCK,
                   reason='retention violation seen, but the answer came '
                          'from the transcript, not from the Stop input '
                          '(cli %s)' % (version or 'unknown'))
        return rec, {}
    lost = lr['demoted'] + lr['altered'] + lr['dropped']
    rec.update(outcome=BLOCKED, reason=lr['reason'], lost_lines=len(lost),
               kept_lines=len(lr['kept']),
               baseline=parent_progress(rows))
    return rec, {'decision': 'block', 'reason': block_reason(lost)}


def log(rec, path=None):
    path = path or os.environ.get(LOG_ENV)
    if not path:
        return
    with open(path, 'a', encoding='utf-8') as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + '\n')


def main(stdin=None, stdout=None):
    stdin = stdin or sys.stdin
    stdout = stdout or sys.stdout
    try:
        event = json.load(stdin)
    except (json.JSONDecodeError, ValueError):
        log({'outcome': NO_BLOCK, 'reason': 'unparsable hook input'})
        return 0
    try:
        rec, out = decide(event)
    except Exception as exc:           # never fail a turn over the trial
        log({'outcome': NO_BLOCK, 'reason': 'hook error: %s' % exc})
        return 0
    log(rec)
    if out:
        json.dump(out, stdout)
    # Nothing to say is said by saying nothing: an empty response keeps the
    # turn end clean for anything reading hook output.
    return 0
